;(function () {

    'use strict';

    angular
        .module('app')
        .controller('FooterBlockController', FooterBlockController);

    FooterBlockController.$inject = ['$state'];

    function FooterBlockController($state) {
        let vm = this;

    }
})();
