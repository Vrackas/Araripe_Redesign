;(function () {

    'use strict';

    angular
        .module('app')
        .controller('SolutionBlockController', SolutionBlockController);

    SolutionBlockController.$inject = ['$state'];

    function SolutionBlockController($state) {
        let vm = this;



    }
})();
