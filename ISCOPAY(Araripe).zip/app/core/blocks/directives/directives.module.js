;(function () {
    'use strict';

    angular.module('blocks.directives', [
        'app.header',
        'app.footer',
        'app.logo',
        'app.top_button',
        'app.solution',
        'app.benefits',
        'app.contact'

    ]);

})();