;(function () {
    'use strict';

    angular.module('app')
        .controller('CookieController', CookieController);


    CookieController.$inject = [];

    function CookieController() {
        var vm = this;

    }
})();