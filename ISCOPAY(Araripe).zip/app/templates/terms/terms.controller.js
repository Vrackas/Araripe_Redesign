;(function () {
    'use strict';

    angular.module('app')
        .controller('TermsController', TermsController);


    TermsController.$inject = [];

    function TermsController() {
        var vm = this;

    }
})();