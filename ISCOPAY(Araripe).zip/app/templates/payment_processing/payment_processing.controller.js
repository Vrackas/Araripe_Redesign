;(function () {
    'use strict';

    angular.module('app')
        .controller('PaymentProcessingController', PaymentProcessingController);


    PaymentProcessingController.$inject = [];

    function PaymentProcessingController() {
        var vm = this;

    }
})();