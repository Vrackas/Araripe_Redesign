;(function () {
    'use strict';

    angular.module('app')
        .controller('MerchantAccountController', MerchantAccountController);


    MerchantAccountController.$inject = [];

    function MerchantAccountController() {
        var vm = this;

    }
})();