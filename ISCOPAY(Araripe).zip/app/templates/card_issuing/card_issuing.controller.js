;(function () {
    'use strict';

    angular.module('app')
        .controller('CardIssuingController', CardIssuingController);


    CardIssuingController.$inject = [];

    function CardIssuingController() {
        var vm = this;

    }
})();