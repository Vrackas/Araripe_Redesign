;(function () {
    'use strict';

    angular.module('app')
        .controller('MerchantAcquiringController', MerchantAcquiringController);


    MerchantAcquiringController.$inject = [];

    function MerchantAcquiringController() {
        var vm = this;

    }
})();