;(function () {
    'use strict';

    angular.module('app')
        .controller('PricesController', PricesController);


    PricesController.$inject = [];

    function PricesController() {
        var vm = this;


    }
})();